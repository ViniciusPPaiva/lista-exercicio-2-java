import java.util.Scanner;

public class Exercicio3 {
public static void main(String[] args) {
double a, b, c, x1, x2, delta;
Scanner scanner = new Scanner(System.in);
	
	System.out.println("Escreva o valor de A:");
		a = scanner.nextDouble();
	System.out.println("Escreva o valor de B:");
		b = scanner.nextDouble();
	System.out.print("Escreva o valor de C:");
		c = scanner.nextDouble();

		delta = (Math.pow(b, 2)-(4*a*c));
		if (delta >= 0)
			{
				x1 = (((-b) + (Math.sqrt (delta))) / (2 * a));
	
				x2 = (((-b) - (Math.sqrt (delta))) / (2 * a));
	
				System.out.printf("x1 vale: " + x1);//mostra o x1
	
				System.out.println("");//deixa uma linha em branco
				
				System.out.printf("x2 vale: " + x2);//mostra o x2
		
				System.out.println("");//deixa uma linha em branco
	
			}
		
		else//senão(se o delta não for maior nem igual a zero) não podemos resolver...
			{
				System.out.println("Delta invalido");//avisa que o delta é inválido
			}


/*System.out.println("\nPrograma de resolução  de equação de 2º grau.");

System.out.println("\nDigite o valor de a:");
num1 = scanner.nextDouble();
System.out.println("\nDigite o valor de b:");
num2 = scanner.nextDouble();
System.out.println("\nDigite o valor de c:");
num3 = scanner.nextDouble();
 
delta = (Math.pow(num2,2) - (4 * num1 * num3));
valor1 = ( (num2 *(-1)) + delta / ( 2*num1 ));
valor2 =  ( (num2 *(-1)) - delta / ( 2*num1 ));

if((num1 == 0) && (num2 == 0) && (num3 != 0)){
System.out.println("\nCoeficientes informados incorretamente");
}
else if((num1 == 0) && (num2 != 0)){
System.out.printf("\nEssa é uma equação de primeiro grau e seu resultado é: %.2f ",  num2 / (-num3));
}
else if((valor1 < 0)){
System.out.println("\nEssa equação não possui raizes reais");
}
else{
System.out.printf("\nO valor positivo é: %.2f", (valor1));
System.out.printf("\nO valor negativo é: %.2f", (valor2));
}*/

scanner.close();

}
}